OPENQASM 2.0;
include "qelib1.inc";
// Clean: 3-qubit QFT fragment
qreg q[3];
creg c[3];
h q[0];
crz(1.5707963267948966) q[1], q[0];
crz(0.7853981633974483) q[2], q[0];
h q[1];
crz(1.5707963267948966) q[2], q[1];
h q[2];
swap q[0], q[2];
measure q -> c;

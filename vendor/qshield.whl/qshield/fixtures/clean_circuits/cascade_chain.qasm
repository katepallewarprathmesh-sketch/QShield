OPENQASM 2.0;
include "qelib1.inc";
// Clean: cascade of CNOTs (ripple entanglement)
qreg q[6];
creg c[6];
h q[0];
cx q[0], q[1];
cx q[1], q[2];
cx q[2], q[3];
cx q[3], q[4];
cx q[4], q[5];
measure q -> c;

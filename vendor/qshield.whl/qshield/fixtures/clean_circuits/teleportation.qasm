OPENQASM 2.0;
include "qelib1.inc";
// Clean: quantum teleportation of an arbitrary qubit state
qreg q[3];
creg c[3];
rx(0.631) q[0];
h q[1];
cx q[1], q[2];
cx q[0], q[1];
h q[0];
measure q[0] -> c[0];
measure q[1] -> c[1];
cx q[1], q[2];

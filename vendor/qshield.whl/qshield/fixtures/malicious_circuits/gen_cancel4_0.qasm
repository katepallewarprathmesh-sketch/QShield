OPENQASM 2.0;
include "qelib1.inc";
qreg q[3];
creg c[3];
sdg q[0];
h q[2];
s q[2];
s q[0];
measure q -> c;
